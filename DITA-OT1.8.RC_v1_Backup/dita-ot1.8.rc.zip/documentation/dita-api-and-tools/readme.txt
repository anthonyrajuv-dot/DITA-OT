DITA API and Tools

See docs/index.html for general documentation. See docs/javadoc/index.html for API and implementation details.

The two jars provide command-line tools and are intended to be run using a Java call of the form:

java -jar {jar file name} {options}

E.g.,

java -jar dita4publishers-mapbosreporter.jar -i /Users/myname/docs/mymap.ditamap

As long as the java command is in your path the command should work.

